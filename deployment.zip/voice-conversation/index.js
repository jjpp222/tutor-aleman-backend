module.exports = async function (context, req) {
    context.log('Voice conversation test endpoint called');

    try {
        context.log('Request body:', req.body);
        const { transcript } = req.body || {};
        context.log('Extracted transcript:', transcript);
        
        if (!transcript) {
            context.res = {
                status: 400,
                body: {
                    success: false,
                    error: 'transcript is required'
                }
            };
            return;
        }

        context.log(`Processing transcript: ${transcript}`);

        // Mock response for testing
        const mockGermanResponse = "Hallo! Mir geht es gut, danke. Wie geht es Ihnen denn? Das ist ein Test.";

        context.res = {
            status: 200,
            body: {
                success: true,
                germanResponse: mockGermanResponse,
                transcript: transcript,
                voiceUsed: 'Mock Voice (Test Mode)',
                sessionId: `voice_test_${Date.now()}`,
                timestamp: new Date().toISOString(),
                pipeline: 'Test mode - no AI/TTS integration yet'
            }
        };

        context.log('Voice conversation test completed successfully');

    } catch (error) {
        context.log.error('Voice conversation test error:', error.message);
        
        context.res = {
            status: 500,
            body: {
                success: false,
                error: error.message,
                timestamp: new Date().toISOString()
            }
        };
    }
};