// Empty index.js file for Azure Functions
// This file is required but not used when functions are in separate directories